phi = 3.14
def luas_lingkaran(r):
    return 3.14 * r **2

def luas_persegi(s):
    return s * s
   

